#! /bin/sh

java -classpath lib/jdbc_lab.jar:/home/student/tomcat/lib/mysql-connector-java-5.1.38-bin.jar java112.project4.JDBCSelectEmployees
