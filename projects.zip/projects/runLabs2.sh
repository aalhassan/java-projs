#! /bin/sh
  
java -classpath lib/java112Labs.jar:config java112.labs2.$1 $2 $3
