package java112.labs1 ;

public class MysteryClassOne {
public static void main(String[] args){
MysteryClassOne mysteryClass = new MysteryClassOne();
System.out.println(mysteryClass.mysteryMethodOne() ) ;

}
public int mysteryMethodOne(){
   return 1;
}
}
