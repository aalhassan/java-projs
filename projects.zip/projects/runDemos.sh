#! /bin/sh

java -classpath lib/java112Demos.jar java112.demo.$1 $2 $3 $4 $5
