#! /bin/sh

java -classpath lib/java112Labs.jar java112.labs1.$1 $2 $3
