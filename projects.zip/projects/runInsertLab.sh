#! /bin/sh

java -classpath lib/jdbc_lab.jar:/home/student/tomcat/lib/mysql-connector-java-5.1.38-bin.jar java112.project4.JDBCInsertEmployee $1 $2 $3 $4 $5 $6
